library(cellcall)
library(magrittr)
library(dplyr)
library(Seurat)


load(file = "08.extract tumor cells/subclass_T.rdata")
test <- CreateObject_fromSeurat(Seurat.object= pbmc, #seurat����
                                slot="counts", 
                                cell_type="celltype", #ϸ������
                                data_source="UMI",
                                scale.factor = 10^6, 
                                Org = "Homo sapines") #������Ϣ


mt <- TransCommuProfile(test,
                        pValueCor = 0.05,
                        CorValue = 0.1,
                        topTargetCor = 1,
                        p.adjust = 0.05,
                        use.type = "mean",
                        probs = 0.9,
                        method = "weighted",
                        Org = "Homo sapiens",
                        IS_core = TRUE)

n <- mt@data$expr_l_r_log2_scale

pathway.hyper.list <- lapply(colnames(n), function(i){
  print(i)
  tmp <- getHyperPathway(data = n, object = mt, cella_cellb = i, Org="Homo sapiens")
  return(tmp)
})
myPub.df <- getForBubble(pathway.hyper.list, cella_cellb=colnames(n))
pdf("09.TF/pathway_T.pdf",he=10,wi=10)
plotBubble(myPub.df)
dev.off()

#�ж���ϸ�����;����ö��ٸ���ɫ
cell_color <- data.frame(color=c("#FF34B3","#BC8F8F","#20B2AA","#00F5FF"), stringsAsFactors = FALSE)
rownames(cell_color) <- c("Cancer cells","CD8+ T cells","CD4+ T cells","regulatory T cells")


cell_color <- data.frame(color=c("#FF34B3","#BC8F8F","#20B2AA"), stringsAsFactors = FALSE)
rownames(cell_color) <- c("Cancer cells","myCAFs","iCAFs")


ViewInterCircos(object = mt, font = 2, cellColor = cell_color, 
                lrColor = c("#F16B6F", "#84B1ED"),
                arr.type = "big.arrow",arr.length = 0.04,
                trackhight1 = 0.05, slot="expr_l_r_log2_scale",
                linkcolor.from.sender = TRUE,
                linkcolor = NULL, gap.degree = 0.5, #ϸ�����Ͷ�Ļ�����С�㣬��Ȼͼ̫�󻭲�����
                order.vector=c('ST', "SSC", "SPGing", "SPGed"),
                trackhight2 = 0.032, track.margin2 = c(0.01,0.12), DIY = FALSE)


########������������ͼ########
pdf("09.TF/heatmap_T.pdf",he=30,wi=10)
viewPheatmap(object = mt, slot="expr_l_r_log2_scale", show_rownames = T,
             show_colnames = T,treeheight_row=0, treeheight_col=10,
             cluster_rows = T,cluster_cols = F,fontsize = 12,angle_col = "90",  
             main="score")
dev.off()

######����ϸ����ת¼���ӻ���#######
Epi.tf <- names(mt@data$gsea.list$`Cancer cells`@geneSets)
Epi.tf

######����ת¼���Ӹ�������#########
pdf("gsea.MEF2C.pdf",he=6,wi=10)
getGSEAplot(gsea.list=mt@data$gsea.list, geneSetID=c("ETS1", "PPARG", "MEF2C"), 
            myCelltype="CAFs", fc.list=mt@data$fc.list,  
            selectedGeneID = mt@data$gsea.list$CAFs@geneSets$MEF2C[1:50],
            mycol = NULL)
dev.off()





#######����ϸ�����͵������弰ת¼����#######
mt <- LR2TF(object = mt, sender_cell="CD8+ T cells", recevier_cell="Cancer cells",
            slot="expr_l_r_log2_scale", org="Homo sapiens")
head(mt@reductions$sankey)

tmp <- mt@reductions$sankey


tmp1 <- dplyr::filter(tmp, weight1>0.5) ## filter triple relation with weight1 (LR score)
tmp.df <- trans2tripleScore(tmp1)  ## transform weight1 and weight2 to one value (weight)

## set the color of node in sankey graph
mycol.vector = c('#5d62b5','#29c3be','#f2726f','#62b58f','#bc95df', '#67cdf2', '#ffc533', '#5d62b5', '#29c3be')  
elments.num <-  tmp.df %>% unlist %>% unique %>% length()
mycol.vector.list <- rep(mycol.vector, times=ceiling(elments.num/length(mycol.vector)))

pdf("09.TF/CD82Cancers.pdf",he=8,wi=12)
sankey_graph(df = tmp.df, axes=1:3, mycol = mycol.vector.list[1:elments.num], nudge_x = NULL, font.size = 4, boder.col="white", isGrandSon = F)
dev.off()

write.table(tmp.df,file = "09.TF/CD82cancers.txt",sep = "\t",row.names = F,quote = F)

## gsea object
egmt <- mt@data$gsea.list$Epithelial

## filter TF
egmt.df <- data.frame(egmt)
head(egmt.df[,1:6])
flag.index <- which(egmt.df$p.adjust < 0.05)


pdf("Epi.pdf",wi=5,he=8)
ridgeplot.DIY(x=egmt, fill="pvalue", showCategory=flag.index, core_enrichment = T,
              orderBy = "NES", decreasing = T)
dev.off()


######չʾת¼���ӵİл���########
CAFs.TG <- mt@data$gsea.list$CAFs@geneSets
Epi.TG <- mt@data$gsea.list$Epithelial@geneSets

