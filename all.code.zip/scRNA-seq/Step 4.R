
library(limma)
library(Seurat)
library(dplyr)
library(magrittr)
library(celldex)
library(SingleR)
library(monocle)

load(file = "04.TSNE/pbmc.rdata")

###################################先用SingleR进行自动注释################判断一下大致分类######
###################################04.SingleR R包注释细胞类型###################################

counts<-pbmc@assays$RNA@counts
clusters<-pbmc@meta.data$seurat_clusters
ann=pbmc@meta.data$orig.ident
ref=get(load("05.Ann/ref_Human_all.RData"))
#ref=celldex::HumanPrimaryCellAtlasData()
#save(ref,file = "05.Ann/ref_Human_all.RData")

singler=SingleR(test=counts, ref =ref,
                labels=ref$label.main, clusters = clusters)
clusterAnn=as.data.frame(singler)
clusterAnn=cbind(id=row.names(clusterAnn), clusterAnn)
clusterAnn=clusterAnn[,c("id", "labels")]
write.table(clusterAnn,file="05.Ann/01.clusterAnn.txt",quote=F,sep="\t", row.names=F)
singler2=SingleR(test=counts, ref =ref, 
                 labels=ref$label.main)
cellAnn=as.data.frame(singler2)
cellAnn=cbind(id=row.names(cellAnn), cellAnn)
cellAnn=cellAnn[,c("id", "labels")]
write.table(cellAnn, file="05.Ann/02.cellAnn.txt", quote=F, sep="\t", row.names=F)

#cluster注释后的可视化
newLabels=singler$labels
names(newLabels)=levels(pbmc)
pbmc=RenameIdents(pbmc, newLabels)
pdf(file="05.Ann/01.tsne.pdf",width=7.5,height=6)
TSNEPlot(object = pbmc, pt.size = 2, label = TRUE)    #TSNE可视化
dev.off()
