library(org.Hs.eg.db)
library(magrittr)
library(dplyr)
library(caTools)
library(pheatmap)

library(infercnv)
library(tidyverse)
library(ComplexHeatmap)
library(circlize)
library("RColorBrewer")

minmax <- function(x, min, max ){
  x[x > max] <- max
  x[x < min] <- min
  return(x)
}

load(file = "06.Ann!R/ann2.rdata")
pbmc@meta.data$celltype <- pbmc@active.ident

pbmc@meta.data$classification <- pbmc@active.ident

cellAnnota <- subset(pbmc@meta.data,select="classification")
cellAnnota <- subset(pbmc@meta.data,select="celltype")

exprMatrix <- as.matrix(GetAssayData(pbmc, slot='counts'))
write.table(exprMatrix, '07.CNV/exprMatrix.txt', sep='\t',col.names = NA)
write.table(cellAnnota, '07.CNV/cellAnnota.txt', col.names=F, sep='\t')

#制作基因定位文件###
dat=read.table("07.CNV/exprMatrix.txt",stringsAsFactors=FALSE, header=TRUE, check.names=FALSE,row.names=1,sep="\t")

library(AnnoProbe)
geneInfor=annoGene(rownames(dat),"SYMBOL","human")
colnames(geneInfor)
geneInfor=geneInfor[with(geneInfor, order(chr, start)),c(1,4:6)]
geneInfor=geneInfor[!duplicated(geneInfor[,1]),]
length(unique(geneInfor[,1]))
head(geneInfor)
# 这里可以去除性染色体
#也可以把染色体排序方式改变
dat=dat[rownames(dat) %in% geneInfor[,1],]
dat=dat[match( geneInfor[,1], rownames(dat) ),] 
dim(dat)
head(geneInfor)
geneFile='07.CNV/geneLocate.txt'
write.table(geneInfor,file = geneFile,sep = '\t',quote = F,col.names = F,row.names = F)


#创建inferCNV的对象
infercnv_obj = CreateInfercnvObject(delim = '\t',
                                    raw_counts_matrix = '07.CNV/exprMatrix.txt',
                                    annotations_file = '07.CNV/cellAnnota.txt',
                                    gene_order_file = '07.CNV/geneLocate.txt',
                                    ref_group_names =c("Endothelial cells","CAFs","B cells","T cells",'Monocyte',"Mast cells"))
dir.create("07.CNV/Results")
#10x数据cutoff推荐使用0.1
infercnv_obj = infercnv::run(infercnv_obj,
                             cutoff=0.1, 
                             out_dir="07.CNV/Results", 
                             cluster_by_groups=TRUE, 
                             denoise=TRUE,
                             HMM=F)



expr <- infercnv_obj@expr.data


normal_loc <- infercnv_obj@reference_grouped_cell_indices
normal_loc_B<- normal_loc$`B cells`
normal_loc_CAFs <- normal_loc$CAFs
normal_loc_T <- normal_loc$`T cells`
normal_loc_Endo <- normal_loc$`Endothelial cells`
normal_loc_Mono <- normal_loc$Monocyte
normal_loc_Mast <- normal_loc$`Mast cells`

#normal_loc <- c(normal_loc$`B cells`,normal_loc$CAFs,normal_loc$`Endothelial cells`,normal_loc$Monocyte,normal_loc$`Mast cells`,normal_loc$`T cells`)
test_loc <- infercnv_obj@observation_grouped_cell_indices
test_loc <- test_loc$`Epithelial cells`


anno.df=data.frame(
  CB=c(colnames(expr)[normal_loc_B],
       colnames(expr)[normal_loc_CAFs],
       colnames(expr)[normal_loc_T],
       colnames(expr)[normal_loc_Endo],
       colnames(expr)[normal_loc_Mono],
       colnames(expr)[normal_loc_Mast],
       colnames(expr)[test_loc]),
  class=c(rep("B cells",length(normal_loc_B)),
          rep("CAFs",length(normal_loc_CAFs)),
          rep("T cells",length(normal_loc_T)),
          rep("Endothelial cells",length(normal_loc_Endo)),
          rep("Monocyte",length(normal_loc_Mono)),
          rep("Mast cells",length(normal_loc_Mast)),
          rep("Epithelial cells",length(test_loc)))
)
head(anno.df)

gn <- rownames(expr)
geneFile <- read.table("07.CNV/geneLocate.txt",header = F,sep = "\t",stringsAsFactors = F)
rownames(geneFile)=geneFile$V1
sub_geneFile <-  geneFile[intersect(gn,geneFile$V1),]
expr=expr[intersect(gn,geneFile$V1),]
head(sub_geneFile,4)
expr[1:4,1:4]

#聚类，7类，提取结果
set.seed(20210418)
kmeans.result <- kmeans(t(expr), 3)
kmeans_df <- data.frame(kmeans_class=kmeans.result$cluster)
kmeans_df$CB=rownames(kmeans_df)
kmeans_df=kmeans_df%>%inner_join(anno.df,by="CB") #合并
kmeans_df_s=arrange(kmeans_df,kmeans_class) #排序
rownames(kmeans_df_s)=kmeans_df_s$CB
kmeans_df_s$CB=NULL
kmeans_df_s$kmeans_class=as.factor(kmeans_df_s$kmeans_class) #将kmeans_class转换为因子，作为热图的一个注释，最终在热图上就会按照1:7排序
head(kmeans_df_s)

#定义热图的注释，及配色
top_anno <- HeatmapAnnotation(foo = anno_block(gp = gpar(fill = "NA",col="NA"), labels = 1:22,labels_gp = gpar(cex = 1.5)))
color_v=RColorBrewer::brewer.pal(3, "Dark2")[1:3] #类别数
names(color_v)=as.character(1:3)
left_anno <- rowAnnotation(df = kmeans_df_s,col=list(class=c("Epithelial cells"="red","B cells" = "blue",
                                                             "CAFs"="yellow","T cells"="green",
                                                             "Endothelial cells"="grey","Monocyte"="#CCE6F1",
                                                             "Mast cells"="#AE7653"),
                                                     kmeans_class=color_v))

#下面是绘图
pdf("07.CNV/try1.pdf",width = 15,height = 10)
ht = Heatmap(t(expr)[rownames(kmeans_df_s),], #绘图数据的CB顺序和注释CB顺序保持一致
             col = colorRamp2(c(0.9,1,1.1), c("#377EB8","#F0F0F0","#E41A1C")), #如果是10x的数据，这里的刻度会有所变化
             cluster_rows = F,cluster_columns = F,show_column_names = F,show_row_names = F,
             column_split = factor(sub_geneFile$V2, paste("chr",1:22,sep = "")), #这一步可以控制染色体顺序，即使你的基因排序文件顺序是错的
             column_gap = unit(2, "mm"),
             
             heatmap_legend_param = list(title = "Modified expression",direction = "vertical",
                                         title_position = "leftcenter-rot",at=c(0.4,1,1.6),
                                         legend_height = unit(3, "cm")),
             
             top_annotation = top_anno,left_annotation = left_anno, #添加注释
             row_title = NULL,column_title = NULL)
draw(ht, heatmap_legend_side = "right")
dev.off()

#每一类对应的CB保存在kmeans_df_s数据框中
write.table(kmeans_df_s, file = "07.CNV/kmeans_df_s.txt", quote = FALSE, sep = '\t', row.names = T, col.names = T)


####绘制每个细胞类型的CNV小提琴图
expr2=expr-1
expr2=expr2^2
CNV_score=as.data.frame(colMeans(expr2))
colnames(CNV_score)="CNV_score"
CNV_score$CB=rownames(CNV_score)
kmeans_df_s$CB=rownames(kmeans_df_s)
CNV_score=CNV_score%>%inner_join(kmeans_df_s,by="CB")

CNV_score%>%ggplot(aes(kmeans_class,CNV_score))+geom_violin(aes(fill=kmeans_class),color="NA")+
  scale_fill_manual(values = color_v)+
  theme_bw()
ggsave("CNV level.pdf",width = 10,height = 6,units = "cm")


###根据CNV找出肿瘤的聚类
kmeans.result$cluster <- as.factor(kmeans.result$cluster)
pbmc@meta.data$K.means <- kmeans.result$cluster
pdf("07.CNV/CNV.cluster.pdf",wi=8.5,he=8)
DimPlot(pbmc,reduction = "tsne",group.by = "K.means",pt.size = 1.5)
dev.off()


###到这步已经找出肿瘤细胞了####
###接下来保存pbmc数据，准备提取子集再分析
save(pbmc,file = "07.CNV/pbmc.rdata")





