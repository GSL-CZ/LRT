
library(limma)
library(Seurat)
library(dplyr)
library(magrittr)
library(celldex)
library(SingleR)
library(monocle)

load(file = "04.TSNE/pbmc.rdata")


#########手动细胞类型鉴定#########
#细胞markers
#ccRCC                CA9, NDUFA4L2
#Macrophage           CD68,CD163
#Monocyte             CD14,LYZ,S100A12,S100A9,S100A8
#Fibrolast            SFRP2,SPARC,MMP2,COL3A1,COL1A1,COL1A2,EMILIN1,PDGFRB
#Endothelial          PECAM1,PLVAP,CDH5,KDR
#NK                   KLRD1,KLRC1
#CD8 T                CD3D,CD3E,CD8A
#CD4 T                CD3D,CD3E,IL7R
#B cells              CD79A,CD79B,MS4A1
#CAFs                 ACTA2,TAGLN
#TAMs                 GPNMB,SLC40A1,MSR1
#Mast cells           TPSAB1,TPSB2,KIT
#Plasma cells         IGKC  

pdf(file = "06.Ann!R/gene3.pdf",wi=12,he=6)
VlnPlot(pbmc,features = c('EPCAM',
                          'PECAM1',
                          'COL3A1',"COL1A2",
                          "CD163","CD68",
                          "CD79A",
                          "CD3D","CD8A","CD4",
                          "GNLY",
                          "PTPRC"))
dev.off()

pdf(file = "06.Ann!R/markers.pdf",wi=22,he=22)
FeaturePlot(pbmc,features = c("PECAM1",
                              "CD3D","CD3E",
                              'EPCAM',"KRT19","KRT18",
                              "LYZ","CD68","CD163","CD14","CD1C","FCER1A",
                              "CD79A",
                              "TPSAB1","TPSB2",
                              "PDGFRB","PDGFRA",'COL3A1','COL1A1',"FAP",'ACTA2',"TAGLN"))
dev.off()

#######
###细胞类型确定
###Epithelial:    2,6,7
###Endothelial:   0
###Monocyte:      3,10
###CAFs：         4,5,8,13
###T:             1,9
###B              11
###Mast:          12

load(file = "04.TSNE/pbmc.rdata")
new.cluster.ids <- c("Endothelial cells",#0
                     "T cells",#1
                     "Epithelial cells",#2
                     "Monocyte",#3
                     "CAFs",#4
                     "CAFs",#5
                     "Epithelial cells",#6
                     "Epithelial cells",#7
                     "CAFs",#8
                     "T cells",#9
                     "Monocyte",#10
                     "B cells",#11
                     'Mast cells',#12
                     "CAFs")#13,
names(new.cluster.ids) <- levels(pbmc)
pbmc <- RenameIdents(pbmc, new.cluster.ids)
pbmc@meta.data$celltype <- pbmc@active.ident

new.ids <- c("Normal",
             "Normal",
             "Tumor",
             "Normal",
             "Normal",
             "Normal",
             "Normal")
names(new.ids) <- levels(pbmc)
pbmc <- RenameIdents(pbmc,new.ids)
pbmc@meta.data$classification <- pbmc@active.ident
pdf(file="06.Ann!R/TSNE.ann2.pdf",width=9.5,height=7)
TSNEPlot(object = pbmc, pt.size = 2, label = TRUE)    #TSNE可视化
dev.off()

save(pbmc,file = "06.Ann!R/ann2.rdata")
load(file = "06.Ann!R/ann2.rdata")

