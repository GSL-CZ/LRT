

load(file = "07.CNV/pbmc.rdata")

###ȡ�Ӽ�
pbmc1 <- subset(pbmc@meta.data,K.means!=1)
pbmc2 <- subset(pbmc@meta.data,celltype=="T cells")

###seuratȡ�Ӽ�
Tumor <- subset(pbmc, cells=row.names(pbmc1))
T_cells <- subset(pbmc, cells=row.names(pbmc2))


###�ϲ������Ӽ�####
pbmc3=merge(Tumor,y=T_cells,
           add.cell.ids = c("Tumor","T cells"),
           project = "Cross_talk")

save(pbmc3,file = "08.extract tumor cells/pbmc_cross_T.rdata")

#####��ȡ������ϸ�������������


#Ѱ�Ҹ߱����
pbmc3 <- FindVariableFeatures(object = pbmc3, selection.method = "vst", nfeatures = 1500)

##PCA����
pbmc3=ScaleData(pbmc3)          #PCA��ά֮ǰ�ı�׼Ԥ��������
pbmc3=RunPCA(object= pbmc3,pc.genes=VariableFeatures(object = pbmc3))     #PCA����

pbmc3 <- JackStraw(object = pbmc3, num.replicate = 100)
pbmc3 <- ScoreJackStraw(object = pbmc3, dims=1:20)
pdf(file="08.extract tumor cells/01.pcaJackStraw_T.pdf",width=8,height=6)
JackStrawPlot(object = pbmc3, dims = 1:20)
dev.off()

pcSelect=20
pbmc3 <- FindNeighbors(object = pbmc3, dims = 1:pcSelect)       #�����ڽӾ���    ѡ����ѵ�PC
pbmc3 <- FindClusters(object = pbmc3, resolution = c(seq(.1,1.6,.2)))         #��ϸ������,��ϸ����׼ģ�黯
clustree(pbmc3@meta.data,prefix="RNA_snn_res.")
pbmc3 <- FindClusters(object = pbmc3, resolution = 0.7) 

####��TSNE����
pbmc3 <- RunTSNE(object = pbmc3, dims = 1:pcSelect)             #TSNE����
pdf(file="08.extract tumor cells/02.TSNE_T.pdf",width=7.5,height=6)
TSNEPlot(object = pbmc3, pt.size = 2, label = TRUE)    #TSNE���ӻ�
dev.off()
write.table(pbmc3,file="05.tsneCluster_T.txt",quote=F,sep="\t",col.names=F)


##����ÿ������Ĳ������
logFCfilter=1               #logFC�Ĺ�������
adjPvalFilter=0.05 
pbmc3.markers <- FindAllMarkers(object = pbmc3,
                               only.pos = FALSE,
                               min.pct = 0.25,
                               logfc.threshold = logFCfilter)  

sig.markers=pbmc3.markers[(abs(as.numeric(as.vector(pbmc3.markers$avg_log2FC)))>logFCfilter & as.numeric(as.vector(pbmc3.markers$p_val_adj))<adjPvalFilter),]

write.table(sig.markers,file="08.extract tumor cells/03.clusterMarkers_T.txt",sep="\t",row.names=F,quote=F)

top10 <- pbmc3.markers %>% group_by(cluster) %>% top_n(n = 10, wt = avg_log2FC)  #�ҳ�ǰ10���������

showGenes=c("EPCAM","KRT19") 


###��Ҫչʾ��ɢ��ͼ�Ļ���
showGenes=c("EPCAM","KRT19",
            "CD8A","CD8B","GZMK",
            "CD3D","CD3E","IL7R","LDHB",
            "FOXP3","IL2RA","IKZF2","PDCD1") 
DotPlot(pbmc3,features = showGenes)

#����marker�ڸ���cluster��ɢ��ͼ
pdf(file="08.extract tumor cells/03.markerScatter.pdf",width=15,height=10)
FeaturePlot(object = pbmc3, features = showGenes, cols = c("grey", "blue"))
dev.off()

new.cluster.ids <- c("Cancer cells",#0
                     "CD4+ T cells",#1
                     "CD8+ T cells",#2
                     "Cancer cells",#3
                     "Cancer cells",#4
                     "regulatory T cells")#5
names(new.cluster.ids) <- levels(pbmc3)
pbmc3 <- RenameIdents(pbmc3, new.cluster.ids)

pdf(file="08.extract tumor cells/TSNE.ann2_T.pdf",width=9.5,height=7)
TSNEPlot(object = pbmc3, pt.size = 2, label = TRUE)    #TSNE可视�?
dev.off()

pbmc3@meta.data$celltype <- pbmc3@active.ident

save(pbmc3,file = "08.extract tumor cells/subclass_T.rdata")

