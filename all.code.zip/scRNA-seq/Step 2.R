

library(limma)
library(Seurat)
library(dplyr)
library(magrittr)
library(celldex)
library(SingleR)
library(monocle)

load(file = "02.QC/pbmc.rdata")

#######PCA 降维########
##PCA分析
pbmc=ScaleData(pbmc)          #PCA降维之前的标准预处理步骤
pbmc=RunPCA(object= pbmc,pc.genes=VariableFeatures(object = pbmc))     #PCA分析

#绘制每个PCA成分的特征基因
pdf(file="03.PCA reduction/01.pcaGene.pdf",width=10,height=8)
VizDimLoadings(object = pbmc, dims = 1:4, reduction = "pca",nfeatures = 20)
dev.off()

#绘制主成分分析图形
pdf(file="03.PCA reduction/02.PCA.pdf",width=6.5,height=6)
DimPlot(object = pbmc, reduction = "pca")
dev.off()

#主成分分析热图
pdf(file="03.PCA reduction/03.pcaHeatmap.pdf",width=10,height=8)
DimHeatmap(object = pbmc, dims = 1:4, cells = 500, balanced = TRUE,nfeatures = 30,ncol=2)
dev.off()

#得到每个PC的p值分布
pbmc <- JackStraw(object = pbmc, num.replicate = 100)
pbmc <- ScoreJackStraw(object = pbmc, dims=1:20)
pdf(file="03.PCA reduction/04.pcaJackStraw.pdf",width=8,height=6)
JackStrawPlot(object = pbmc, dims = 1:20)
dev.off()
ElbowPlot(pbmc,ndims=50, reduction="pca")


###################################03.TSNE聚类分析和marker基因###################################
##TSNE聚类分析
pcSelect=35
pbmc <- FindNeighbors(object = pbmc, dims = 1:pcSelect)       #计算邻接距离    选择最佳的PC
#pbmc <- FindClusters(object = pbmc, resolution = c(seq(.1,1.6,.2)))         #对细胞分组,对细胞标准模块化
#clustree(pbmc@meta.data,prefix="RNA_snn_res.")
pbmc <- FindClusters(object = pbmc, resolution = 0.5) 



####用TSNE聚类
pbmc <- RunTSNE(object = pbmc, dims = 1:pcSelect)             #TSNE聚类
pdf(file="03.PCA reduction/05.TSNE.pdf",width=7.5,height=6)
TSNEPlot(object = pbmc, pt.size = 2, label = TRUE)    #TSNE可视化
dev.off()
write.table(pbmc$seurat_clusters,file="05.tsneCluster.txt",quote=F,sep="\t",col.names=F)


##查找每个聚类的差异基因
logFCfilter=1               #logFC的过滤条件
adjPvalFilter=0.05 
pbmc.markers <- FindAllMarkers(object = pbmc,
                               only.pos = FALSE,
                               min.pct = 0.25,
                               logfc.threshold = logFCfilter)  

sig.markers=pbmc.markers[(abs(as.numeric(as.vector(pbmc.markers$avg_log2FC)))>logFCfilter & as.numeric(as.vector(pbmc.markers$p_val_adj))<adjPvalFilter),]

write.table(sig.markers,file="03.PCA reduction/03.clusterMarkers.txt",sep="\t",row.names=F,quote=F)

top10 <- pbmc.markers %>% group_by(cluster) %>% top_n(n = 10, wt = avg_log2FC)  #找出前10个差异基因


#绘制marker在各个cluster的热图
pdf(file="04.TSNE/01.tsneHeatmap.pdf",width=12,height=16)
DoHeatmap(object = pbmc, features = top10$gene) + NoLegend()
dev.off()

#绘制marker的小提琴图
pdf(file="04.TSNE/02.markerViolin.pdf",width=10,height=6)
VlnPlot(object = pbmc, features = row.names(sig.markers)[1:2])
dev.off()

save(pbmc,file = "04.TSNE/pbmc.rdata")


#需要展示的基因，可以修改
showGenes=c("KRT18","KRT19") 

#绘制marker在各个cluster的散点图
pdf(file="03.markerScatter.pdf",width=10,height=6)
FeaturePlot(object = pbmc, features = showGenes, cols = c("green", "red"))
dev.off()

#绘制marker在各个cluster的气泡图
pdf(file="03.markerBubble.pdf",width=12,height=6)
cluster10Marker=showGenes
DotPlot(object = pbmc, features = cluster10Marker)
dev.off()








