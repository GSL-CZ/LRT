

load(file = "06.Ann!R/ann.rdata")

##比较两个类别之间的差异基因
cluster.markers <- FindMarkers(pbmc,ident.1 = "Cancer associated fibroblasts",ident.2 = "Epithelial cells",min.pct = 0.25)
write.table(cluster.markers,file="CAFs&Epi.txt",sep="\t",quote=F)
