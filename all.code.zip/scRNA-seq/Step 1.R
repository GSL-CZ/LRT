library(Seurat)
library(limma)

########读取化疗耐药的膀胱癌单细胞数据集###########

rt1 <- read.table("GSM4307111_GEO_processed_BC159-T_3_log2TPM_matrix_final.txt",sep="\t",header=T,row.names = 1)
pbmc <- CreateSeuratObject(counts = rt1,project = "BLCA",
                           min.cells = 3,min.features = 50,names.delim = "_")

######好习惯之~~~保存数据###
save(pbmc,file = "01.data deposition/pbmc.rdata")
load(file = "01.data deposition/pbmc.rdata")

#######计算线粒体占比#######
pbmc[["percent.mt"]] <- PercentageFeatureSet(object = pbmc,pattern = "^MT-")

####根据需要对数据进行过滤#####
#pbmc=subset(x = pbmc, subset = nFeature_RNA > 200 & nFeature_RNA <5000 & percent.mt < 10)


#########################
######quality check######
#########################

#绘制基因特征的小提琴图
pdf(file="02.QC/01.featureViolin.pdf", width=10, height=6)
VlnPlot(object = pbmc, features = c("nFeature_RNA", "nCount_RNA", "percent.mt"), ncol = 3)
dev.off()

#测序深度的相关性图
pdf(file="02.QC/02.featureCor.pdf",width=10,height=6)
plot1 <- FeatureScatter(object = pbmc, feature1 = "nCount_RNA", feature2 = "percent.mt",pt.size=1.5)
plot2 <- FeatureScatter(object = pbmc, feature1 = "nCount_RNA", feature2 = "nFeature_RNA",,pt.size=1.5)
CombinePlots(plots = list(plot1, plot2))
dev.off()


#对数据进行标准化
pbmc <- NormalizeData(object = pbmc, normalization.method = "LogNormalize", scale.factor = 10000)

#提取细胞间变异系数较大的基因
pbmc <- FindVariableFeatures(object = pbmc, selection.method = "vst", nfeatures = 1500)

#输出特征方差图
top10 <- head(x = VariableFeatures(object = pbmc), 10)
pdf(file="02.QC/03.featureVar.pdf",width=10,height=6)
plot1 <- VariableFeaturePlot(object = pbmc)
plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
CombinePlots(plots = list(plot1, plot2))
dev.off()

save(pbmc,file = "02.QC/pbmc.rdata")








