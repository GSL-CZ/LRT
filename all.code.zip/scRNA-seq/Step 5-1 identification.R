library(dplyr)
library(Seurat)
library(patchwork)
library(reshape2)
library(RColorBrewer)
library(scales)
library(ggplot2)
library(ggpubr)
library(ggplotify)
library(pheatmap)

load(file = "06.Ann!R/ann.rdata")
pbmc@meta.data$celltype <- pbmc@active.ident
celltype <- c("Endothelial cells",
              "T cells",
              "Epithelial cells",
              "Monocyte",
              "B cells",
              "Mast cells",
              "CAFs")
pbmc@meta.data$celltype <- factor(pbmc@meta.data$celltype, levels = celltype)

## 从上述标注细胞类型信息可知0,2,4属于T，1,5属于Mono，3属于B，6属于NK，7属于DC，8属于Platelet
## 所以设定cluster为factor，levels=c(0,2,4,1,5,3,6,7,8)
cluster <- c(0,1,9,2,6,7,3,10,11,12,4,5,8,13)
pbmc@meta.data$seurat_clusters <- factor(pbmc@meta.data$seurat_clusters,levels=cluster)


#选择四个基因进行平均表达量展示
select_gene <- c("ACTA2","FAP","COL1A1","COL1A2")
Idents(pbmc) <- "seurat_clusters"
AveExpression <- AverageExpression(pbmc, assays = "RNA", features = select_gene,verbose = TRUE) %>% .$RNA
#AveExpression$Gene <- rownames(AveExpression)
Ave_df <- melt(AveExpression,id.vars= "Gene")
colnames(Ave_df) <- c("Gene", "Cluster", "Expression")
Ave_df$Group <- paste(Ave_df$Cluster,Ave_df$Gene,sep = "_")
Ave_df$Expression[which(Ave_df$Expression>10)] <- 10
####设置平均表达量大于10的值为10，放置画出来的bar太高，按照自己数据情况设定

pB1 <- ggplot(Ave_df,aes(x=Gene, y=Expression))+
  geom_hline(yintercept = seq(0, 10, 2.5),linetype = 2, color = "lightgray",size=1)+
  geom_line()+
  geom_segment(aes(x=Gene,xend=Gene,y=0,yend=Expression),color="lightgray",size = 1.5)+
  geom_point(size=3,aes(color=Gene))+
  scale_color_manual(values=c("#00AFBB", "#E7B800", "#FC4E07", "#41ab5d")) +
  theme_bw()+
  theme(panel.grid =element_blank()) +
  labs(x="",y="Gene exp.")

pB1 <- facet(pB1, facet.by = "Cluster",ncol = length(unique(Ave_df$Cluster)),panel.labs.font = list(size = 12),panel.labs.background = list(fill = "#a6cee3"))

pB1 <- pB1 + scale_y_continuous(position = "right")+  ####用来将y轴移动位置
  theme(axis.text.y = element_text(size=12, colour = "black"))+
  theme(axis.text.x = element_blank())+ ## 删去所有刻度标签# theme(axis.text.y = element_blank())   ## 设置 axis.text.y 则只删去 Y 轴的刻度标签，X 轴同理。
  theme(axis.title.y = element_text(size=12, colour = "black"))+
  theme(axis.title.x = element_blank())+
  theme(legend.position = "right",
        panel.border = element_blank(),## 去掉最外层的正方形边框 
        axis.ticks.x = element_line(color =  NA))

pB1



####此处可计算细胞类型的marker用于展示，这里选择用于鉴定细胞类型的marker
##自定义颜色
colourCount = length(unique(pbmc@meta.data$celltype))
getPalette = colorRampPalette(brewer.pal(8, "Dark2"))
celltype_colors <- getPalette(colourCount)


#heatmap_gene <- c("PECAM1",
"CD3D","CD3E",
'EPCAM',"KRT19","KRT18",
"LYZ","CD68","CD163","CST3","CD14","CD1C","FCER1A",
"COL10A1",'COL3A1','COL1A1','MMP11',
'ACTA2',"TAGLN","MYH11","MCAM","MYLK",
"CXCL12","CXCL14","C3","CFD","FGF7",
"CD79A",
"TPSAB1","TPSB2",
"DCN","IGFBP2","PDGFRA","PDPN","FAP")

heatmap_gene <- c("PECAM1",
                  "CD3D","CD3E",
                  'EPCAM',"KRT19","KRT18",
                  "LYZ","CD68","CD14",
                  "CD79A",
                  "TPSAB1","TPSB2",
                  "PDGFRB","PDGFRA",'COL3A1','COL1A1',"FAP",'ACTA2',"TAGLN")

heatmap_AveE <- AverageExpression(pbmc, assays = "RNA", features = heatmap_gene,verbose = TRUE) %>% .$RNA

gene_num <- c(1,2,3,3,1,2,7)
gaps_row <- cumsum(gene_num)

cluster_num <- c(1,2,3,2,1,1,4)
gaps_col <- cumsum(cluster_num)

bk <- c(seq(-2,-0.1,by=0.01),seq(0,2,by=0.01))
annotation_row <- data.frame(row.names = rownames(heatmap_AveE),
                             `CellType` = rep(factor(celltype,levels = celltype),gene_num))
annotation_col <- data.frame(row.names = colnames(heatmap_AveE),
                             `CellType` = rep(factor(celltype,levels = celltype),cluster_num))
annotation_colors = list(`CellType` = celltype_colors)
names(annotation_colors$`CellType`) = celltype
ph3 <- pheatmap(heatmap_AveE,cluster_cols = F,cluster_rows = F,show_colnames=F,show_rownames=T,
                border=F,#border_color = "white",
                color = c(colorRampPalette(colors = c("#2166ac","#f7fbff"))(length(bk)/2),
                          colorRampPalette(colors = c("#f7fbff","#b2182b"))(length(bk)/2)),
                breaks=bk,scale="row",legend_breaks=seq(-2,2,2),
                gaps_row = gaps_row,gaps_col = gaps_col,
                annotation_row = annotation_row,annotation_col = annotation_col,
                annotation_colors = annotation_colors,
                annotation_names_row = F,annotation_names_col = T)

require(ggplotify)
pB3 = as.ggplot(ph3) ### 将pheatmap对象转为ggplot对象，便于后续拼图

