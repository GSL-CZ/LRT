library(rio)
rt=import("29.response/IMVigor210/inflammed.txt")
rt=rt[,c(1,4)]
colnames(rt)=c("ID","response")
rt=na.omit(rt)

rt$response=ifelse(rt$response=="CR/PR","Response","Non_response")

risk=import("29.response/IMVigor210/PCA.score.txt")
risk=risk[,c(1,4)]
colnames(risk)=c("ID","risk")
risk$risk=ifelse(risk$risk>-10.9,"High","Low")

rt1=merge(risk,rt,by="ID")

data=data.frame(table(rt1$risk,rt1$response))

library(plyr)
data<- ddply(data,.(Var1),transform,percent=Freq/sum(Freq)*100)

data$label = paste0(sprintf("%.1f", data$percent), "%")

abc=matrix(data$Freq,nrow = 2,ncol = 2)
pvalue <- chisq.test(abc)$p.value

pvalue <- fisher.test(abc)$p.value

library(ggplot2)
##开始画图
ggplot(data,aes(Var1,percent,fill=Var2))+
  geom_bar(stat="identity",position = position_stack())+
  scale_fill_manual(values = c("#DB423E","#008ECA"),label=c("Non_response","Response"))+
  scale_y_continuous(labels = scales::percent_format(scale = 1))+ #百分比y轴
  labs(x="Risk",y="Relative Percentage",fill="")+
  geom_text(aes(label=label),vjust=3,size=6,color="black")+
  annotate(geom = "text",
           cex=6,
           x=1.5, y=105, # 根据自己的数据调节p value的位置
           label=paste0("P ", ifelse(pvalue<0.001, "< 0.001", paste0("= ",round(pvalue,3)))), # 添加P值
           color="black")+
  theme_classic()+
  theme(legend.position = "top",
        legend.text = element_text(size=12),
        axis.text = element_text(size=12),
        axis.title = element_text(size=12))
ggsave("inflamed.bar.pdf",wi=4,he=5)

