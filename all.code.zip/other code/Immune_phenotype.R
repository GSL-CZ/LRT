library(rio)
library(tidyverse)
library(dplyr)
library(plyr)
library(ggplot2)
sxk=function(x){
  rownames(x)=x[,1]
  x=x[,-1]
}
rt=import("time.txt")
rt=rt[,c(1,7)]
rt=na.omit(rt)

rt1=import("PCA.score.txt")
rt1=rt1[,c(1,4)]
colnames(rt1)=c("ID","Risk")

rt2=merge(rt,rt1,by="ID")
rt2=sxk(rt2)

library(reshape2)
library(viridis)
library(ggpubr)
data=melt(rt2,id.vars = "Immune_phenotype")
colnames(data)=c("Immune_phenotype","Type","Risk")

data %>%
  ggplot( aes(x=Immune_phenotype, y=Risk, fill=Immune_phenotype)) +
  geom_boxplot() +
    scale_fill_viridis(discrete = TRUE, alpha=0.6, option="D") +
  theme(legend.position="none",
    plot.title = element_text(size=11)) +
  theme_classic()+
  xlab("Immune_phenotype")+
  theme(axis.title.x = element_text(size = 12,face = "bold", vjust = 0.5))+
  theme(axis.title.y = element_text(size = 12,face = "bold", vjust = 0.5))+
  theme(axis.text.x = element_text(size = 11,face = "bold",color = "black", vjust = 0.5))+
  theme(axis.text.y = element_text(size = 11,face = "bold",color = "black", vjust = 0.5))+
  stat_compare_means(comparisons = list(c("desert","excluded"),
                                        c("desert","inflamed"),
                                        c("excluded","inflamed")),face="bold",
                     symnum.args=list(cutpoints = c(0, 0.001, 0.01, 0.05, 1), symbols = c("***", "**", "*", " ")),
                     label = "p.signif")+
  stat_compare_means(method = "anova",label.y = 80)+
  guides(fill="none")
ggsave("Immune_phenotype.pdf",wi=4,he=6)




