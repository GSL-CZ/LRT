
library(limma)
library(readr)
library(data.table)
library(rio)


data=import("1.Datasets/normalize/imv.normalize.txt")
rownames(data)=data[,1]
data=data[,-1]
gene=read.table("21.TIScompute/genes.txt", header=F, check.names=F, sep="\t")

sameGene=intersect(as.vector(gene[,1]),rownames(data))
geneExp=data[sameGene,]

out=rbind(ID=colnames(geneExp),geneExp)
out1=t(out)
out1=out1[,-1]
write.table(out1,file="29.response/IMVigor210/TIScompute.imv.txt",sep="\t",quote=F)

##计算得分
rt=import("29.response/IMVigor210/TIScompute.imv.txt")
rownames(rt) <- rt[,1]
rt=rt[,-1]
rt=log2(rt+1)

#genes <- c("CCL5","CD27","CD274","CD276","CD8A","CMKLR1","CXCL9",
#           "CXCR6","HLA-DQA1","HLA-DRB1","HLA-E","IDO1","LAG3",
#           "NKG7","PDCD1LG2","PSMB10","STAT1","TIGIT")


rt$TIS_score <- (0.008346*rt$CCL5)+(0.072293*rt$CD27)+(0.042853*rt$CD274)+(-0.0239*rt$CD276)+
  (0.031021*rt$CD8A)+(0.151253*rt$CMKLR1)+(0.074135*rt$CXCL9)+(0.004313*rt$CXCR6)+
  (0.020091*rt$`HLA-DQA1`)+(0.058806*rt$`HLA-DRB1`)+(0.07175*rt$`HLA-E`)+(0.060679*rt$IDO1)+
  (0.123895*rt$LAG3)+(0.075524*rt$NKG7)+(0.003734*rt$PDCD1LG2)+(0.032999*rt$PSMB10)+
  (0.250229*rt$STAT1)+(0.084767*rt$TIGIT)
write.table(rt,file ="29.response/IMVigor210/TIS_scores.imv.txt",quote = F,sep = "\t",row.names = T)





