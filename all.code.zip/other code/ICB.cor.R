

rt1=import("20.ICB/ICI.txt")

rt2=import('1.Datasets/normalize/normlize.tcga.tpm.log2.tumor.txt')
rownames(rt2)=rt2[,1]
rt2=rt2[,-1]
rt2=rt2[rt1$Genes,rt3$ID]
rt2=as.data.frame(t(rt2))
rt2$ID=rownames(rt2)
rt3=import("4.consensusCluster/Cluster/cluster=2.txt")

rt4=merge(rt3,rt2,by="ID")
rownames(rt4)=rt4[,1]
rt4=rt4[,-1]
rt4=rt4[order(rt4$cluster),]
rt4=rt4[,-1]
##热图

annotation_col <- data.frame(
  LRT_cluster = c(rep("clusterA",times=215),rep("clusterB",times=193))
)
rownames(annotation_col) <- colnames(t(rt4))

ann_colors <- list(LRT_cluster=c(clusterA="#FF9933",clusterB="#009966"))

pdf("20.ICB/ICI.cluster.pdf",he=8,wi=6)
pheatmap(t(rt4),
         scale = "row",
         cluster_=T,
         show_colnames = F,
         cluster_rows = F,
         cluster_cols = F,
         #gaps_row = c(42,62,80),
         gaps_col =215,
         annotation_col = annotation_col,
         #annotation_row = annotation_row,
         color = colorRampPalette(c("#0066CC","black", "#FFFF99"))(200),
         breaks = seq(-2,2,length.out=200),
         annotation_colors = ann_colors)
dev.off()


###相关性蝴蝶图
rt1=import("20.ICB/ICI.txt")

rt2=import('1.Datasets/normalize/normlize.tcga.tpm.log2.tumor.txt')
rownames(rt2)=rt2[,1]
rt2=rt2[,-1]
rt2=rt2[rt1$Genes,rt3$ID]
rt2=as.data.frame(t(rt2))
rt2$ID=rownames(rt2)
rt3=import("9.computePCA/output_LRT_scorePlus.txt")
rt3=rt3[,c(1,4)]
colnames(rt3)=c("ID","RiskScore")

rt4=merge(rt2,rt3,by="ID")
rownames(rt4)=rt4[,1]
rt4=rt4[,-1]
rt4=as.data.frame(t(rt4))

RiskScore=rt3$RiskScore

# 循环计算相关性并绘制左下角
CorRisk <- NULL
for (i in rownames(rt4)) {
  cr <- cor.test(as.numeric(rt4[i,]),
                 as.numeric(RiskScore),
                 method = "pearson")
  CorRisk <- rbind.data.frame(CorRisk,
                                     data.frame(gene = "RiskScore",
                                                path = i,
                                                r = cr$estimate,
                                                p = cr$p.value,
                                                stringsAsFactors = F),
                                     stringsAsFactors = F)
}
CorRisk$sign <- ifelse(CorRisk$r > 0,"pos","neg")
CorRisk$absR <- abs(CorRisk$r)
CorRisk$rSeg <- as.character(cut(CorRisk$absR,c(0,0.25,0.5,0.75,1),labels = c("0.25","0.50","0.75","1.00"),include.lowest = T))
CorRisk$pSeg <- as.character(cut(CorRisk$p,c(0,0.001,0.01,0.05,1),labels = c("<0.001","<0.01","<0.05","ns"),include.lowest = T))
CorRisk[nrow(CorRisk),"pSeg"] <- "Not Applicable"

CorRisk$rSeg <- factor(CorRisk$rSeg, levels = c("0.25","0.50","0.75","1.00"))
CorRisk$pSeg <- factor(CorRisk$pSeg, levels = c("<0.001","<0.01","<0.05","Not Applicable","ns"))
CorRisk$sign <- factor(CorRisk$sign, levels = c("pos","neg"))

p1 <- quickcor(t(rt4), 
               type = "upper",
               show.diag = TRUE) + 
  geom_colour() +
  add_link(df = CorRisk, 
           mapping = aes(colour = pSeg, size = rSeg, linetype = sign),
           spec.key = "gene",
           env.key = "path",
           diag.label = FALSE) +
  scale_size_manual(values = c(0.5, 1, 1.5, 2)) +
  scale_color_manual(values = c("#19A078","#DA6003","#7570B4","#E8288E","#65A818")) +
  scale_fill_gradient2(low = "#9483E1",mid = "white",high = "#E11953",midpoint=0) +
  remove_axis("x")
p1
ggsave(filename = "20.ICB/ggcor plot in bottom right.pdf", width = 12,height = 8)




