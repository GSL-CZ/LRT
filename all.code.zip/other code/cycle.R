sam=import("1.Datasets/normalize/tcga.sam.txt")

rt1=import("4.consensusCluster/Cluster/cluster.k=2.consensusClass.csv")
colnames(rt1)=c("ID","cluster")
rt1$cluster=ifelse(rt1$cluster==1,"A","B")
rownames(rt1)=rt1[,1]

rt1=import("9.repeatedLasso/tcga.riskscore.txt")
colnames(rt1)=c("ID","Risk")
rt1$Risk=ifelse(rt1$Risk>-0.33,"High","Low")
rownames(rt1)=rt1[,1]

rt2=import("14.cycle/2.Cancer immunity cycle.txt")
rownames(rt2)=rt2[,1]
rt2=rt2[,-1]
colnames(rt2)=substr(colnames(rt2),1,12)
rt2=rt2[,sam$ID]
rt2=as.data.frame(t(rt2))

comsam=intersect(rownames(rt2),rt1$ID)
rt2=rt2[comsam,]
rt1=rt1[comsam,]
data=cbind(rt1,rt2)

data=data[,-1]
data=data[order(data$cluster),]
table(data$cluster)
data=data[,-1]

data=data[,-1]
data=data[order(data$Risk),]
table(data$Risk)
data=data[,-1]

###设置颜色
annotation_col <- data.frame(
  LRT_cluster = c(rep("clusterA",times=215),rep("clusterB",times=193))
)
rownames(annotation_col) <- colnames(t(data))
ann_colors <- list(LRT_cluster=c("clusterA"="#FF9933","clusterB"="#009966"))

ann_colors <- list(Risk=c("High"="#FF9933","Low"="#009966"))

annotation_col <- data.frame(
  Risk = c(rep("High",times=203),rep("Low",times=200))
)
rownames(annotation_col) <- colnames(t(data))

pdf("14.cycle/cycle.cluster.pdf",he=8,wi=12)
pheatmap(t(data),
         scale = "row",
         show_colnames = F,
         cluster_rows = F,
         cluster_cols = F,
         gaps_row = c(1,2,3,20,21,22,23),
         gaps_col =203,
         annotation_col = annotation_col,
         #annotation_row = annotation_row,
         color = colorRampPalette(c("#0066CC", "BLACK", "#FFFF00"))(200),
         annotation_colors = ann_colors,
         breaks = seq(-2,2,length.out=200))
dev.off()



