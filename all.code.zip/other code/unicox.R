library(limma)
library(survival)


#读取表达文件，并对输入文件整理
rt=read.table("7.clusterDEGs/diffexp1.txt", header=T, sep="\t", check.names=F)
rownames(rt)=rt[,1]
rt=rt[,-1]

#读取生存数据
cli=read.table("5.survivalCluster/time.txt", header=T, sep="\t", check.names=F, row.names=1)     #读取临床文件
cli$futime=cli$futime/365

#数据合并
sameSample=intersect(colnames(rt), row.names(cli))
rt=rt[,sameSample]
cli=cli[sameSample,]
data=cbind(cli, t(rt))

#对基因进行循环，找出预后相关的基因
outTab=data.frame()
sigGenes=c()
for(i in colnames(data[,3:ncol(data)])){
  #cox分析
  cox <- coxph(Surv(futime, fustat) ~ data[,i], data = data)
  coxSummary = summary(cox)
  coxP=coxSummary$coefficients[,"Pr(>|z|)"]
  if(coxP<0.05){
    sigGenes=c(sigGenes,i)
    outTab=rbind(outTab,
                 cbind(id=i,
                       HR=coxSummary$conf.int[,"exp(coef)"],
                       HR.95L=coxSummary$conf.int[,"lower .95"],
                       HR.95H=coxSummary$conf.int[,"upper .95"],
                       pvalue=coxSummary$coefficients[,"Pr(>|z|)"])
    )
  }
}
dir.create("8.uniox")
#输出单因素的结果
write.table(outTab,file="8.uniox/uniCox.txt",sep="\t",row.names=F,quote=F)

#保存单因素显著基因的表达量
sigGeneExp=rt[sigGenes,]
sigGeneExp=rbind(id=colnames(sigGeneExp), sigGeneExp)
write.table(sigGeneExp, file="8.uniox/uniSigGeneExp.txt", sep="\t", quote=F, col.names=F)

#保存单因素显著基因表达和生存合并的文件
sigExpTime=data[,c("futime", "fustat", sigGenes)]
sigExpTime=rbind(id=colnames(sigExpTime), sigExpTime)
write.table(sigExpTime, file="8.uniox/uniSigExpTime.txt", sep="\t", quote=F, col.names=F)

