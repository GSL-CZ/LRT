
expr <- read.table("1.Datasets/normalize/tcga.normalize.txt",
                   sep = "\t",row.names = 1,check.names = F,stringsAsFactors = F,header = T)
expr <- expr[,-c(1:19)]
colnames(expr) <- substr(colnames(expr),1,12)
expr <- expr[,rownames(annCol)]

tumsam <- colnames(expr)

#indata <- t(scale(t(log2(expr + 1)))) # z-score表达谱
indata <- t(scale(t(expr)))

# 加载亚型结果
annCol <- read.table("4.consensusCluster/Cluster/cluster=2.txt",sep = "\t",row.names = 1,check.names = F,stringsAsFactors = F,header = T)
table(annCol$cluster)

# 加载Figure201ClusterCorrelation的ICI signature gene结果
outTab <- read.table("4.consensusCluster/ouput_ICIsignatureGene.txt",sep = "\t",row.names = NULL,header = T,stringsAsFactors = F,check.names = F)
table(outTab$direct) # AB两种签名按相关性正负来分类，正相关标为A，否则标为B


###########预后相关基因######
rt1=read.table("8.uniox/uniCox.txt",sep = "\t",header = T)

##########PCA降维##########
# 在“输入文件”那里，已经做过z-score处理，因此这里不再进行标准化
expr.A <- indata[rt1$id,rownames(annCol)]
pca.A <- prcomp(t(expr.A), scale = F, center = F) # 如果数据没有标准化，这里都要设置为TRUE
pca1.A <- pca.A$x[,1] # 取出第一主成分
pca1.B <- pca.A$x[,2] # 取出第二主成分


LRT.score <- pca1.A + pca1.B # 主成份相减得到ICI得分


LRT.outtab <- data.frame(samID = rownames(annCol),
                         pca1.A = pca1.A[rownames(annCol)],
                         pca1.B = pca1.B[rownames(annCol)],
                         LRT.score = LRT.score[rownames(annCol)],
                         subtype = annCol$cluster,
                         stringsAsFactors = F)

LRT.score <- pca1.A
LRT.outtab <- data.frame(samID = rownames(annCol),
                         pca1.A = pca1.A[rownames(annCol)],
                         #pca1.B = pca1.B[rownames(annCol)],
                         LRT.score = LRT.score[rownames(annCol)],
                         subtype = annCol$cluster,
                         stringsAsFactors = F)
# 输出到文件
write.table(LRT.outtab,"9.computePCA/output_LRT_scoreA.txt",sep = "\t",row.names = F,col.names = T,quote = F)

ggplot(data = LRT.outtab,aes(x = subtype, y = LRT.score, fill = subtype))+
  scale_fill_manual(values = c("#008ECB", "#EA921D", "#D14039")) + 
  geom_violin(alpha=0.4, position = position_dodge(width = .75),
              size=0.8, color="black") + # 边框线黑色
  geom_boxplot(notch = TRUE, outlier.size = -1, 
               color="black", lwd=0.8, alpha = 0.7)+ # 背景色透明化
  geom_point(shape = 21, size=2, 
             position = position_jitterdodge(), 
             color="black", alpha=1)+ # 边框线黑色
  theme_classic() +
  ylab(expression("LRT score")) +
  xlab("Subtype")  +
  theme(axis.ticks = element_line(size=0.2,color="black"),
        axis.ticks.length = unit(0.2,"cm"),
        legend.position = "none",
        axis.title = element_text(size = 12),
        axis.text = element_text(size = 10)) +
  stat_compare_means(method = "kruskal.test", label.y = max(LRT.score))
ggsave(filename = "LRT_scoreA.pdf", width = 5, height = 5)

