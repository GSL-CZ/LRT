
library(rio)
rt1=import("9.computePCA/output_LRT_scorePlus.txt")
rt1=rt1[,c(1,4)]
rt1$LRT.score=ifelse(rt1$LRT.score>-1.149,"High","Low")

rt4=import("4.consensusCluster/Cluster/cluster=2.txt")
rt4=merge(rt4,rt1,by.x = "ID",by.y = "samID")
rownames(rt4)=rt4[,1]
rt4=rt4[,-1]
annotation_col=rt4

rt2=import("23.theraputic/therputic.txt")
rownames(rt2)=rt2[,1]
rt2=rt2[,-1]
rt2=rt2[,rownames(rt4)]
rt2=as.data.frame(t(rt2))
rt3=cbind(rt1,rt2)
rt3=rt3[order(rt3$LRT.score),]
rownames(rt3)=rt3[,1]
rt3=rt3[,-1]
rt3=rt3[,-1]
##绘制标签
annotation_col <- data.frame(
  list(LRT.score = c(rep("High",times=204),rep("Low",times=204)),
       cluster=c(rep("A",times=204),rep("B",times=204)))
)
rownames(annotation_col) <- colnames(t(rt3))

annotation_row <- data.frame(
  Type=c(rep("EGFR_Network",times=1),rep("Immune_inhibited_oncogenic_pathways",times=6),
         rep("Radiotherapy_predicted_pathways",times=3))
)
rownames(annotation_row) <- rownames(t(rt3))

ann_colors <- list(LRT.score=c(High="#FF9933",Low="#009966"),
                   cluster=c(A="#996699",B="#669999"),
                   Type=c(EGFR_Network="#336633",
                          Immune_inhibited_oncogenic_pathways="#CCCC00",
                          Radiotherapy_predicted_pathways="#333399"))



pdf("23.theraputic/therputic.risk.pdf",he=8,wi=8.5)
pheatmap(t(rt3),
         scale = "row",
         cluster_=T,
         show_colnames = F,
         cluster_rows = F,
         cluster_cols = F,
         gaps_row = c(1,7,10),
         gaps_col =204,
         annotation_col = annotation_col,
         annotation_row = annotation_row,
         color = colorRampPalette(c("#009966","white", "#CC3333"))(100),
         breaks = seq(-3,3,length.out = 100),
         annotation_colors = ann_colors)
dev.off()









