library(ggplot2)
library(ggExtra)
library(ggpubr)


rt=import("8.pan.TIS/panTIS_scores.txt")
rt=as.data.frame(t(sxk(rt)))
colnames(rt)=substr(colnames(rt),1,12)
rt=rt[,!duplicated(colnames(rt))]
rt=as.data.frame(t(rt))

rt1=import('1.datasets/TCGA/tcga.blca.tpm.txt')
rt1=sxk(rt1)
rt1=rt1["HSPA5",]
rt1=log2(rt1+1)
colnames(rt1)=substr(colnames(rt1),1,12)
rt1=rt1[,!duplicated(colnames(rt1))]
rt1=as.data.frame(t(rt1))
rt1$ID=rownames(rt1)

com=intersect(rownames(rt),rownames(rt1))
rt=rt[com,]
rt1=rt1[com,]
rt2=cbind(rt,rt1)

rt2=rt2[,c(19,20)]
colnames(rt2)=c("TIS","HSPA5")

p <- ggplot(rt2, aes(x=HSPA5, y=TIS)) +
  geom_point() +
  theme_light()+
  geom_smooth(method="lm",se=F,formula = y~x)+
  stat_cor(method = 'pearson', aes(x =HSPA5, y =TIS))+
  theme_bw(base_size = 20,base_line_size = 0.8)

p1 <- ggMarginal(p, type="histogram",
                 xparams=list(fill = "#CC3333",color="#CC3333"), 
                 yparams=list(fill = "#003366",color="#003366"))
p1

pdf("8.pan.TIS/BLCA.TIS_cor_score.pdf",wi=5,he=5)
p1
dev.off()

