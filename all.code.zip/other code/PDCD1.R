
library(rio)
rt1=import("24.IMvigor/3.ICIs/ICI.txt")
rt1[21,]="IGF2BP2"

sxk=function(x){
  rownames(x)=x[,1]
  x=x[,-1]
}
fpkmToTpm <- function(fpkm){
  exp(log(fpkm) - log(sum(fpkm)) + log(1e6))
}

rt2=import('24.IMvigor/1.dataset/IMvigor.FPKM.txt')
rt2=sxk(rt2)
rt2=2^rt2-1
tpm=apply(rt2, 2, fpkmToTpm)
rt2=as.data.frame(log2(tpm+1))

IGF2BP2=rt2[rt1$Genes,]
IGF2BP2=as.data.frame(t(IGF2BP2))

rt3=as.data.frame(t(IGF2BP2))

library(corrplot)
M=cor(t(rt3))
res1=cor.mtest(t(rt3), conf.level = 0.95)

pdf(file="cor.imv.pdf", width=11, height=10)
corrplot(M,
         order="original",
         method = "color",
         diag = F,
         type = "lower",
         is.corr = T, 
         mar = c(0,0,0,0),
         addCoef.col = "black",
         tl.cex=0.8, 
         pch=T,
         #p.mat = res1$p,
         insig = "label_sig",
         pch.cex = 1.6,
         sig.level=0.05,
         number.cex = 1,
         col=colorRampPalette(c("#003366", "white", "#CC3333"))(200),
         tl.col="black")
dev.off()

rt5=as.data.frame(t(rt4))
hav=rt5[,c(10,21)]
colnames(hav)=c("PDCD1","LRT.score")

p <- ggplot(hav, aes(x=LRT.score, y=PDCD1)) +
  geom_point() +
  theme_light()+
  geom_smooth(method="lm",color="red", fill="#69b3a2",se=F,formula = y~x)+
  stat_cor(method = 'spearman', aes(x =LRT.score, y =PDCD1))+
  theme_classic(base_size = 15,base_line_size = 1)+
  geom_rug(col="steelblue",alpha=0.1, size=1.5)
p

pdf("PDCD1.cor.pdf",wi=4,he=4)
p
dev.off()
