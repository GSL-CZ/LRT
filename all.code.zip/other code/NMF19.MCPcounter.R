#���ð�
library(limma)
library(MCPcounter)

data=import("1.Datasets/normalize/tcga.normalize.txt")
rownames(data)=data[,1]
data=data[,-1]
data=data[,-c(1:19)]
#����ϸ������
MCPcounter.estimate=MCPcounter.estimate(data,
	featuresType="HUGO_symbols",
	probesets=read.table("16.MCP-COUNTER/probesets.txt",sep="\t",stringsAsFactors=FALSE,colClasses="character"),
	genes=read.table("16.MCP-COUNTER/genesets.txt",sep="\t",stringsAsFactors=FALSE,header=TRUE,colClasses="character",check.names=FALSE)
)
out=rbind(ID=colnames(MCPcounter.estimate), MCPcounter.estimate)
out=out[,!duplicated(substr(colnames(out),1,12))]
out=out[-1,]
out=as.data.frame(t(out))
rownames(out)=substr(rownames(out),1,12)
write.table(out, file="16.MCP-COUNTER/MCPcounter.result.txt", sep="\t", quote=F)

