
rt=import("18.effector/TILs.txt")

rt1=import("1.Datasets/normalize/normlize.tcga.tpm.log2.tumor.txt")
rownames(rt1)=rt1[,1]
rt1=rt1[,-1]
rt2=import('1.Datasets/normalize/tcga.sam.txt')
rt1=rt1[rt$Gene,rt2$ID]
rt1=as.data.frame(t(rt1))
rt1$ID=rownames(rt1)

rt2=import("4.consensusCluster/Cluster/cluster=2.txt")

rt4=merge(rt1,rt2,by="ID")
rownames(rt4)=rt4[,1]
rt4=rt4[,-1]
rt4=rt4[order(rt4$cluster),]
rt4=rt4[,-ncol(rt4)]
###画热图
annotation_col <- data.frame(
  LRT_cluster = c(rep("clusterA",times=215),rep("clusterB",times=193))
)
rownames(annotation_col) <- colnames(t(rt4))

annotation_row <- data.frame(
  Type=c(rep("CD8_T_cell",times=12),rep("Dendritic_cell",times=6),
         rep("Macrophage",times=8),rep("NK_cell",times=6),rep("Th1_cell",times=3))
)
rownames(annotation_row) <- rownames(t(rt4))

ann_colors <- list(LRT_cluster=c(clusterA="#FF9933",clusterB="#009966"),
                   Type=c(CD8_T_cell="#336633",Dendritic_cell="#CCCC00",Macrophage="#333399",NK_cell="#FF6600",Th1_cell="#0099CC"))

pdf("18.effector/effector.tcga.cluster.pdf",he=6,wi=4.5)
pheatmap(t(rt4),
         scale = "row",
         cluster_=T,
         show_colnames = F,
         cluster_rows = F,
         cluster_cols = F,
         gaps_row = c(12,18,26,32,35),
         gaps_col =215,
         annotation_col = annotation_col,
         annotation_row = annotation_row,
         color = colorRampPalette(c("#0066CC","BLACK", "#FFFF00"))(200),
         breaks = seq(-2,2,length.out=200),
         annotation_colors = ann_colors)
dev.off()
