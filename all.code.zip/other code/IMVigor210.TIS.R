library(ggplot2)
library(ggExtra)
library(ggpubr)


rt=import("29.response/IMVigor210/TIS_scores.imv.txt")
rt=rt[,c(1,20)]
colnames(rt)=c("ID","TIS_score")

rt1=import('29.response/IMVigor210/PCA.score.txt')
rt1=rt1[,c(1,4)]
colnames(rt1)=c("ID","LRT.score")

rt2=merge(rt,rt1,by="ID")
rownames(rt2)=rt2[,1]
rt2=rt2[,-1]


p <- ggplot(rt2, aes(x=LRT.score, y=TIS_score)) +
  geom_point() +
  theme_light()+
  geom_smooth(method="lm",se=F,formula = y~x)+
  stat_cor(method = 'spearman', aes(x =LRT.score, y =TIS_score))+
  theme_bw(base_size = 20,base_line_size = 0.8)

p1 <- ggMarginal(p, type="histogram",
                 xparams=list(fill = "#CC3333",color="#CC3333"), 
                 yparams=list(fill = "#003366",color="#003366"))
p1

pdf("29.response/IMVigor210/TIS_cor_score.imv.pdf",wi=5,he=5)
p1
dev.off()

