
rt1=import("15.TIMER/immuneEstimation.txt")

#rt2=import("4.consensusCluster/Cluster/cluster=2.txt")
#rt2$ID=paste0(rt2$ID,"-01")

rt2=import("9.computePCA/output_LRT_scorePlus.txt")
rt2=rt2[,c(1,4)]
colnames(rt2)=c("ID","Risk")
rt2$ID=paste0(rt2$ID,"-01")


sam=intersect(rt1$ID,rt2$ID)
rt1=rt1[rt1$ID %in%sam,]
rt2=rt2[rt2$ID %in%sam,]

rt=cbind(rt2,rt1)
rt=rt[,-3]

rownames(rt)=rt[,1]
rt=rt[,-1]


data=melt(rt,id.vars = "cluster")
colnames(data)=c("cluster","Cell","Infiltration level")

p=ggboxplot(data, x="Cell", y="Infiltration level", fill = "cluster", 
            color = "cluster",
            ylab="Infiltration level",
              xlab="TIMER",
            legend.title="cluster",
            palette = c("#CC3333", "#003366"),
            width = 0.5,horizontal=F)
p=p+rotate_x_text(90)
p1=p+stat_compare_means(aes(group=cluster),
                        method="wilcox.test",
                        symnum.args=list(cutpoints = c(0, 0.001, 0.01, 0.05, 1), symbols = c("***", "**", "*", " ")),
                        label = "p.signif")
p1

pdf("15.TIMER/TIMER.TCGA.pdf",wi=8,he=4.5)
p1
dev.off()

##Risk
rt$Risk=ifelse(rt$Risk>9.33,"High","Low")
rt=rt[order(rt$Risk),]

data=melt(rt,id.vars = "Risk")
colnames(data)=c("Risk","Cell","Infiltration level")

p=ggboxplot(data, x="Cell", y="Infiltration level", fill = "Risk", 
            color = "Risk",
            ylab="Infiltration level",
            xlab="TIMER",
            legend.title="Risk",
            palette = c("#CC3333", "#003366"),
            width = 0.5,horizontal=F)
p=p+rotate_x_text(90)
p1=p+stat_compare_means(aes(group=Risk),
                        method="wilcox.test",
                        symnum.args=list(cutpoints = c(0, 0.001, 0.01, 0.05, 1), symbols = c("***", "**", "*", " ")),
                        label = "p.signif")
p1

pdf("15.TIMER/TIMER.TCGA.risk.pdf",wi=8,he=4.5)
p1
dev.off()
