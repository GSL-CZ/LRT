
rt=import("19.hyperProgression/hyperprogression.txt")

rt1=import("1.Datasets/normalize/normlize.tcga.tpm.log2.tumor.txt")
rownames(rt1)=rt1[,1]
rt1=rt1[,-1]
rt2=import('1.Datasets/normalize/tcga.sam.txt')
rt1=rt1[rt$Genes,rt2$ID]
rt1=as.data.frame(t(rt1))
rt1$ID=rownames(rt1)

rt2=import("4.consensusCluster/Cluster/cluster=2.txt")
rt2=import('9.computePCA/output_LRT_scorePlus.txt')
rt2=rt2[,c(1,4)]
colnames(rt2)=c("ID","Risk")
rt2$Risk=ifelse(rt2$Risk>-1.3,"High","Low")
rt2=rt2[order(rt2$Risk),]

rt4=merge(rt1,rt2,by="ID")
rownames(rt4)=rt4[,1]
rt4=rt4[,-1]
rt4=rt4[order(rt4$cluster),]

data=melt(rt4,id.vars = "cluster")
colnames(data)=c("cluster","Genes","Expression")

p=ggboxplot(data, x="Genes", y="Expression", fill = "cluster", 
            color = "cluster",
            ylab="Expression",
            xlab="HyperProgression",
            legend.title="cluster",
            palette = c("#CC3333", "#003366"),
            width = 0.5,horizontal=F)
p=p+rotate_x_text(0)
p1=p+stat_compare_means(aes(group=cluster),
                        method="wilcox.test",
                        symnum.args=list(cutpoints = c(0, 0.001, 0.01, 0.05, 1), symbols = c("***", "**", "*", " ")),
                        label = "p.signif")
p1

pdf("19.hyperProgression/hyperprogression.cluster.pdf",wi=7,he=3.5)
p1
dev.off()

###
rt4=rt4[order(rt4$Risk),]
data=melt(rt4,id.vars = "Risk")
colnames(data)=c("Risk","Genes","Expression")

p=ggboxplot(data, x="Genes", y="Expression", fill = "Risk", 
            color = "Risk",
            ylab="Expression",
            xlab="HyperProgression",
            legend.title="Risk",
            palette = c("#CC3333", "#003366"),
            width = 0.5,horizontal=F)
p=p+rotate_x_text(0)
p1=p+stat_compare_means(aes(group=Risk),
                        method="wilcox.test",
                        symnum.args=list(cutpoints = c(0, 0.001, 0.01, 0.05, 1), symbols = c("***", "**", "*", " ")),
                        label = "p.signif")
p1

pdf("19.hyperProgression/hyperprogression.Risk.pdf",wi=7,he=3.5)
p1
dev.off()
