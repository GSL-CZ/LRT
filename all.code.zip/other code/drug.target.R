
library(rio)
rt1=import("9.computePCA/output_LRT_scorePlus.txt")
rt1=rt1[,c(1,4)]
rt1$LRT.score=ifelse(rt1$LRT.score>-1.149,"High","Low")

rt4=import("4.consensusCluster/Cluster/cluster=2.txt")
rt4=merge(rt4,rt1,by.x = "ID",by.y = "samID")
rownames(rt4)=rt4[,1]
rt4=rt4[,-1]
annotation_col=rt4

rt2=import('22.drug/drug.txt',sep="$")
colnames(rt2)=c("therapy","drug","target")

rt=import("1.Datasets/normalize/normlize.tcga.tpm.log2.tumor.txt")
rownames(rt)=rt[,1]
rt=rt[,-1]
rt=rt[rt2$target,rt1$samID]
rt=as.data.frame(t(rt))
rt$ID=rownames(rt)
rt=rt[,-27]


rt3=merge(rt,rt1,by.x = "ID",by.y = "samID")
rownames(rt3)=rt3[,1]
rt3=rt3[,-1]
rt3=rt3[order(rt3$LRT.score),]
table(rt3$LRT.score)
rt3=rt3[,-ncol(rt3)]
##绘制标签
annotation_row <- data.frame(
  Type=c(rep("Chemotherapy",times=15),rep("Immunotherapy",times=1),
         rep("ERBB_Therapy",times=14),rep("Antiangiogenic_Therapy",times=9))
)
rownames(annotation_row) <- rownames(t(rt3))

ann_colors <- list(LRT.score=c(High="#FF9933",Low="#009966"),
                   cluster=c(A="#996699",B="#669999"),
                   Type=c(Chemotherapy="#336633",Immunotherapy="#CCCC00",ERBB_Therapy="#333399",Antiangiogenic_Therapy="#FF6600"))



pdf("22.drug/drug.risk.pdf",he=8,wi=6)
pheatmap(t(rt3),
         scale = "row",
         cluster_=T,
         show_colnames = F,
         cluster_rows = F,
         cluster_cols = F,
         gaps_row = c(15,16,30,39),
         gaps_col =204,
         annotation_col = annotation_col,
         annotation_row = annotation_row,
         color = colorRampPalette(c("#0066CC","BLACK", "#FFFF00"))(100),
         breaks = seq(-2,2,length.out = 100),
         annotation_colors = ann_colors)
dev.off()









