
#install.packages("survival")
#install.packages("survminer")
#install.packages("timeROC")


library(survival)
library(survminer)
library(timeROC)

im=import("9.repeatedLasso/imv.riskscore.txt")
im1=import("1.Datasets/normalize/IMVtime.txt")
im1=im1[,c(1:3)]
colnames(im)=c("ID","riskscore_imv")
im2=merge(im1,im,by= "ID")
rownames(im2)=im2[,1]
svdata=im2[,-1]
colnames(svdata)=c("futime","fustat","riskScore_imv")

rt=svdata
rt$futime=rt$futime*30/365
#绘制
ROC_rt=timeROC(T=rt$futime, delta=rt$fustat,
	           marker=rt$riskScore_imv, cause=1,
	           weighting='aalen',
	           times=c(0.5,1,2), ROC=TRUE)
pdf(file="12.timeROC/imv.roc.pdf",width=5,height=5)
plot(ROC_rt,time=0.5,col='#FF6600',title=FALSE,lwd=2)
plot(ROC_rt,time=1,col='#336699',add=TRUE,title=FALSE,lwd=2)
plot(ROC_rt,time=2,col='#009966',add=TRUE,title=FALSE,lwd=2)
legend('bottomright',
	   c(paste0('AUC at 0.5 years: ',sprintf("%.03f",ROC_rt$AUC[1])),
	     paste0('AUC at 1 years: ',sprintf("%.03f",ROC_rt$AUC[2])),
	     paste0('AUC at 2 years: ',sprintf("%.03f",ROC_rt$AUC[3]))),
	     col=c('#336699','#009966'),lwd=2,bty = 'n')
dev.off()


######Video source: https://ke.biowolf.cn
######??????ѧ??: https://www.biowolf.cn/
######΢?Ź??ںţ?biowolf_cn
######???????䣺biowolf@foxmail.com
######????΢??: 18520221056
