library(rio)
rt=import("26.immuneCells/infiltration_estimation_for_tcga.csv")


rt1=import("9.computePCA/output_LRT_scorePlus.txt")
rt1$samID=paste0(rt1$samID,"-01")
rt1=rt1[,c(1,4)]


rt2=merge(rt,rt1,by.x = "cell_type",by.y = "samID")
rownames(rt2)=rt2[,1]
rt2=rt2[,-1]
library(corrplot)

M=cor(rt2)

write.table(M,file = "26.immuneCells/infiltration.cor.tcga.txt",sep = "\t",quote = F,row.names = T,col.names = NA)
