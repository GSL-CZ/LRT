

rt=import("21.TIScompute/TIS_scores.txt")

rt1=import('4.consensusCluster/Cluster/cluster=2.txt')

rt2=merge(rt,rt1,by="ID")
rownames(rt2)=rt2[,1]
rt2=rt2[,-1]
rt2=rt2[,c(19,20)]

data=melt(rt2,id.vars="cluster")
colnames(data)=c("cluster","TIS","TIS_Score")
data=data[order(data$cluster),]


p=ggboxplot(data, x="cluster", y="TIS_Score", fill = "cluster", 
            color = "cluster",
            ylab="TIS_Score",
            xlab="LRT_cluster",
            legend.title="LRT_cluster",
            palette = c("#CC3333", "#003366"),
            width = 0.5,horizontal=F)
p=p+rotate_x_text(0)
p1=p+stat_compare_means(aes(group=cluster),
                        method="wilcox.test",
                        symnum.args=list(cutpoints = c(0, 0.001, 0.01, 0.05, 1), symbols = c("***", "**", "*", " ")),
                        label = "p.signif")
p1

pdf("21.TIScompute/TIS.cluster.pdf",wi=4,he=6)
p1
dev.off()

