library(rio)
sxk=function(x){
  rownames(x)=x[,1]
  x=x[,-1]
}
fpkmToTpm <- function(fpkm){
  exp(log(fpkm) - log(sum(fpkm)) + log(1e6))
}

rt=import("24.IMvigor/10.PD-L1/time.txt")
rt=rt[,c(1,5)]
rt=na.omit(rt)

rt2=import('24.IMvigor/1.dataset/IMvigor.FPKM.txt')
rt2=sxk(rt2)
rt2=2^rt2-1
tpm=apply(rt2, 2, fpkmToTpm)
rt2=as.data.frame(log2(tpm+1))

IGF2BP2=rt2["IGF2BP2",]
IGF2BP2=as.data.frame(t(IGF2BP2))
IGF2BP2$ID=rownames(IGF2BP2)

rt4=merge(IGF2BP2,rt,by="ID")
rt2=rt4
rt2=sxk(rt2)

data=melt(rt2,id.vars = "IC_level")
colnames(data)=c("IC_level","Type","IGF2BP2")

data %>%
  ggplot( aes(x=IC_level, y=IGF2BP2, fill=IC_level)) +
  geom_boxplot() +
  scale_fill_viridis(discrete = TRUE, alpha=0.6, option="D") +
  theme(legend.position="none",
        plot.title = element_text(size=11)) +
  theme_classic()+
  xlab("PD-L1 on Immune cells")+
  theme(axis.title.x = element_text(size = 12,face = "bold", vjust = 0.5))+
  theme(axis.title.y = element_text(size = 12,face = "bold", vjust = 0.5))+
  theme(axis.text.x = element_text(size = 11,face = "bold",color = "black", vjust = 0.5))+
  theme(axis.text.y = element_text(size = 11,face = "bold",color = "black", vjust = 0.5))+
  stat_compare_means(comparisons = list(c("IC0","IC1"),
                                        c("IC0","IC2"),
                                        c("IC1","IC2")),face="bold",
                     symnum.args=list(cutpoints = c(0, 0.001, 0.01, 0.05, 1), symbols = c("***", "**", "*", "ns")),
                     label = "p.signif")+
  stat_compare_means(method = "anova",label.y = 7)+  #这边根据基因的表达水平选择Y轴高度
  guides(fill="none")
ggsave("24.IMvigor/10.PD-L1/IC.pdf",wi=4,he=6)




