library(data.table)
library(GSVA)
library(ggplot2)
library(ggcor)
rt=import("25.immunepathway/immuno.gsva.txt")
rownames(rt)=rt[,1]
rt=rt[,-1]


rt1=import("9.computePCA/output_LRT_scorePlus.txt")
rt1=rt1[,c(1,4)]

rt=rt[,rt1$samID]
rt=as.data.frame(t(rt))

rt2=cbind(rt,rt1)
rt2=rt2[,-18]
#rt2$LRT.score=ifelse(rt2$LRT.score>-1.33,"High","Low")

library(reshape2)
data=melt(rt2,id.vars = "LRT.score")
colnames(data)=c("LRT.score","pathway","Enrichment score")
data=data[order(data$LRT.score),]

p=ggboxplot(data, x="pathway", y="Enrichment score", fill = "LRT.score", 
            color = "LRT.score",
            ylab="Enrichment score",
            xlab="Immune predicted pathways",
            legend.title="LRT.score",
            palette = c("#CC3333", "#003366"),
            width = 0.5,horizontal=F)
p=p+rotate_x_text(60)
p1=p+stat_compare_means(aes(group=LRT.score),
                        method="wilcox.test",
                        symnum.args=list(cutpoints = c(0, 0.001, 0.01, 0.05, 1), symbols = c("***", "**", "*", " ")),
                        label = "p.signif")
p1

pdf("25.immunepathway/immunpathway.risk.pdf",wi=12,he=6.5)
p1
dev.off()

### 相关性分析

RiskScore=rt2$LRT.score

rt4=as.data.frame(t(rt2))
# 循环计算相关性并绘制左下角
CorRisk <- NULL
for (i in rownames(rt4)) {
  cr <- cor.test(as.numeric(rt4[i,]),
                 as.numeric(RiskScore),
                 method = "pearson")
  CorRisk <- rbind.data.frame(CorRisk,
                              data.frame(gene = "RiskScore",
                                         path = i,
                                         r = cr$estimate,
                                         p = cr$p.value,
                                         stringsAsFactors = F),
                              stringsAsFactors = F)
}
CorRisk$sign <- ifelse(CorRisk$r > 0,"pos","neg")
CorRisk$absR <- abs(CorRisk$r)
CorRisk$rSeg <- as.character(cut(CorRisk$absR,c(0,0.25,0.5,0.75,1),labels = c("0.25","0.50","0.75","1.00"),include.lowest = T))
CorRisk$pSeg <- as.character(cut(CorRisk$p,c(0,0.001,0.01,0.05,1),labels = c("<0.001","<0.01","<0.05","ns"),include.lowest = T))
CorRisk[nrow(CorRisk),"pSeg"] <- "Not Applicable"

CorRisk$rSeg <- factor(CorRisk$rSeg, levels = c("0.25","0.50","0.75","1.00"))
CorRisk$pSeg <- factor(CorRisk$pSeg, levels = c("<0.001","<0.01","<0.05","Not Applicable","ns"))
CorRisk$sign <- factor(CorRisk$sign, levels = c("pos","neg"))

p1 <- quickcor(t(rt4), 
               type = "lower",
               show.diag = TRUE) + 
  geom_colour() +
  add_link(df = CorRisk, 
           mapping = aes(colour = pSeg, size = rSeg, linetype = sign),
           spec.key = "gene",
           env.key = "path",
           diag.label = FALSE) +
  scale_size_manual(values = c(0.5, 1, 1.5, 2)) +
  scale_color_manual(values = c("#19A078","#DA6003","#7570B4","#E8288E","#65A818")) +
  scale_fill_gradient2(low = "#9483E1",mid = "white",high = "#E11953",midpoint=0) +
  remove_axis("x")
p1
ggsave(filename = "25.immunepathway/pathway.risk.pdf", width = 12,height = 8)








