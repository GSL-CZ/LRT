library(rio)
library(plyr)

cluster=import("3.cluster/ConsensusCluster/ConsensusCluster.k=2.consensusClass.csv")
colnames(cluster)=c("ID","cluster")
cluster$cluster=ifelse(cluster$cluster==1,"A","B")

cluster=import("9.computePCA/output_LRT_scorePlus.txt")
cluster=cluster[,c(1,4)]
colnames(cluster)=c("ID","Risk")
cluster$Risk=ifelse(cluster$Risk>-1.3,"High","Low")

CNV=import("28.mutation/hyper.txt",header=T)
CNV$ID=substr(CNV$ID,1,12)
CNV=as.data.frame(t(CNV))
colnames(CNV)=CNV[1,]
CNV=CNV[-1,]
CNV=CNV[,!duplicated(colnames(CNV))]
CNV=as.data.frame(t(CNV))
CNV$ID=rownames(CNV)

CNV.cluster=merge(cluster,CNV,by="ID")
CNV.cluster=CNV.cluster[order(CNV.cluster$Risk),]
CNV.cluster=CNV.cluster[!duplicated(CNV.cluster$ID),]
rownames(CNV.cluster)=CNV.cluster[,1]
CNV.cluster=CNV.cluster[,-1]

data=melt(CNV.cluster,id.vars=('Risk'))
colnames(data)=c("Risk","Genes","CNV")


CCND1 <- data.frame(table(data$Risk ,data$Genes,data$CNV))
CCND1 <- CCND1[order(CCND1$Var2),]

CCND1<- ddply(CCND1,.(Var2,Var1),transform,percent=Freq/sum(Freq)*100) 
CCND1$label = paste0(sprintf("%.2f", CCND1$percent), "%")
a=CCND1
a$group=paste0(a$Var2,a$Var1," Risk")
a=a[order(a$Var3),]

p <- ggplot(a,aes(group,percent,fill=Var3))+
  geom_bar(stat="identity",position = position_stack())+
  scale_fill_manual(values = c("#DB423E","#008ECA","#003366"),label=c("Gain","Loss","Neutral"))+
  #scale_y_continuous(labels = scales::percent_format(scale = 1))+ #百分比y轴
  labs(x="HyperProgression",y="Relative Proportion",
       fill="")+
  #geom_text(aes(label=label),vjust=3,size=2,color="black")+
  #annotate(geom = "text",
  #         cex=6,
  #         x=1.5, y=105, # 根据自己的数据调节p value的位置
  #         label=paste0("P ", ifelse(pvalue<0.001, "< 0.001", paste0("= ",round(pvalue,3)))), # 添加P值
  #         color="black")+
  theme_classic()+
  theme(legend.position = "right",
        legend.text = element_text(size=12),
        axis.text = element_text(size=12),
        axis.title = element_text(size=12))
p1=p+rotate_x_text(90)

pdf("28.mutation/cnv.tcga.risk.pdf",wi=10,he=6)
p1
dev.off()
