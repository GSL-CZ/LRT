
library(rio)
rt1=import("9.computePCA/output_LRT_scorePlus.txt")
rt1=rt1[,c(1,4)]
rt1$LRT.score=ifelse(rt1$LRT.score>-1.149,"High","Low")

rt2=import("30.functional/oncogenic/oncogenic.sig.txt")
rownames(rt2)=rt2[,1]
rt2=rt2[,-1]
rt2=rt2[,rt1$samID]

rt2=as.data.frame(t(rt2))
rt3=cbind(rt1,rt2)
rt3=rt3[order(rt3$LRT.score),]
rownames(rt3)=rt3[,1]
rt3=rt3[,-1]
rt3=rt3[,-1]

##绘制标签
annotation_col <- data.frame(
  list(LRT.score = c(rep("High",times=204),rep("Low",times=204)))
)
rownames(annotation_col) <- colnames(t(rt3))

ann_colors <- list(LRT.score=c(High="#FF9933",Low="#009966"))



pdf("30.functional/oncogenic/oncogenic.tcga.pdf",he=28,wi=16)
pheatmap(t(rt3),
         scale = "row",
         cluster_=T,
         show_colnames = F,
         cluster_rows = F,
         cluster_cols = F,
         #gaps_row = c(1,7,10),
         gaps_col =204,
         annotation_col = annotation_col,
         #annotation_row = annotation_row,
         color = colorRampPalette(c("#0066CC","black", "#FFFF00"))(100),
         breaks = seq(-2,2,length.out = 100),
         annotation_colors = ann_colors)
dev.off()









