
rt=import("29.response/IMVigor210/time.txt")
rt=rt[,c(1,6)]
rt=na.omit(rt)

rt1=import("29.response/IMVigor210/PCA.score.txt")
rt1=rt1[,c(1,4)]
colnames(rt1)=c("ID","Risk")

rt2=merge(rt,rt1,by="ID")
rt2=sxk(rt2)

data=melt(rt2,id.vars = "TC_level")
colnames(data)=c("TC_level","Type","Risk")

data %>%
  ggplot( aes(x=TC_level, y=Risk, fill=TC_level)) +
  geom_boxplot() +
  scale_fill_viridis(discrete = TRUE, alpha=0.6, option="D") +
  theme(legend.position="none",
        plot.title = element_text(size=11)) +
  theme_classic()+
  xlab("PD-L1 in TC")+
  theme(axis.title.x = element_text(size = 12,face = "bold", vjust = 0.5))+
  theme(axis.title.y = element_text(size = 12,face = "bold", vjust = 0.5))+
  theme(axis.text.x = element_text(size = 11,face = "bold",color = "black", vjust = 0.5))+
  theme(axis.text.y = element_text(size = 11,face = "bold",color = "black", vjust = 0.5))+
  stat_compare_means(comparisons = list(c("TC0","TC1"),
                                        c("TC0","TC2+"),
                                        c("TC1","TC2+")),face="bold",
                     symnum.args=list(cutpoints = c(0, 0.001, 0.01, 0.05, 1), symbols = c("***", "**", "*", "ns")),
                     label = "p.signif")+
  stat_compare_means(method = "anova",label.y = 80)+
  guides(fill="none")
ggsave("TC.pdf",wi=4,he=6)




