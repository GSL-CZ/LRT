
library(rio)
rt1=import("9.computePCA/output_LRT_scorePlus.txt")
rt1=rt1[,c(1,4)]
rt1$LRT.score=ifelse(rt1$LRT.score>-1.149,"High","Low")

rt4=import("4.consensusCluster/Cluster/cluster=2.txt")
rt4=merge(rt4,rt1,by.x = "ID",by.y = "samID")
rownames(rt4)=rt4[,1]



rt5=import("11.subtypeROC/subtype.5mC.txt")
rt=rownames(rt4)
rt5$ID=substr(rt5$ID,1,12)
rt5=as.data.frame(t(rt5))
colnames(rt5)=rt5[1,]
rt5=rt5[-1,]
rt5=rt5[,!duplicated(colnames(rt5))]

rt5=as.data.frame(t(rt5))
rt5$ID=rownames(rt5)
rt4=merge(rt5,rt4,by="ID")
rownames(rt4)=rt4[,1]
rt4=rt4[,-1]
annotation_col=rt4


rt2=import("24.bladdercancer pathway/bladder sig.txt")
rownames(rt2)=rt2[,1]
rt2=rt2[,-1]
rt2=rt2[,rownames(rt4)]
rt2=as.data.frame(t(rt2))
rt3=cbind(rt1,rt2)
rt3=rt3[order(rt3$LRT.score),]
rownames(rt3)=rt3[,1]
rt3=rt3[,-1]
rt3=rt3[,-1]
##绘制标签
ann_colors <- list(LRT.score=c(High="#FF9933",Low="#009966"),
                   cluster=c(A="#FF9933",B="#009966"),
                   Consensus_subtype=c(Ba_Sq="#CC3333",
                                       LumNS="#336666",
                                       LumP="#CCFFFF",
                                       LumU="#3366CC",
                                       NE_like="#CCCCFF",
                                       Stroma_rich="#FF9900"),
                   CIT_subtype=c(MC1="#99CCCC",
                                 MC2="#0066CC",
                                 MC3="#0099CC",
                                 MC4="#FFCC99",
                                 MC5="#009966",
                                 MC6="#FF9966",
                                 MC7="#CC3333"),
                   Lund_subtype=c(Ba_Sq="#996600",
                                  Ba_Sq_Inf="#CC3333",
                                  GU="#99CC99",
                                  GU_Inf="#663366",
                                  Mes_like="#FF9900",
                                  Sc_NE_like="#CCCCFF",
                                  UroA_Prog="#99CCCC",
                                  UroB="#3366CC",
                                  UroC="#993333",
                                  Uro_Inf="#CCFFFF"),
                   MDA_subtype=c(basal="#CC3333",
                                 luminal="#CCFFFF",
                                 p53_like="#0066CC"),
                   TCGA_subtype=c(Basal_squamous="#CC3333",
                                  Luminal="#0066CC",
                                  Luminal_infiltrated="#FF9900",
                                  Luminal_papillary="#336666",
                                  Neuronal="#CC6699"),
                   Baylor_subtype=c(Basal="#CC3333",
                                    Differentiated="#99CC99"),
                   UNC_subtype=c(Basal="#CC3333",
                                 Luminal="#336666"))



pdf("24.bladdercancer pathway/bladder.pdf",he=11,wi=14)
pheatmap(t(rt3),
         scale = "row",
         cluster_=T,
         show_colnames = F,
         cluster_rows = F,
         cluster_cols = F,
         #gaps_row = c(1,7,10),
         gaps_col =204,
         annotation_col = annotation_col,
         #annotation_row = annotation_row,
         color = colorRampPalette(c("#0066CC","black", "#FFFF00"))(100),
         breaks = seq(-2,2,length.out = 100),
         annotation_colors = ann_colors)
dev.off()

write.table(rt4,file = "12.sanky/sanky.txt",sep = "\t",quote = F,row.names = T,col.names = NA)








