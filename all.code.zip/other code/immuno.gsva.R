
rt=import("1.Datasets/normalize/normlize.tcga.tpm.log2.tumor.txt")
rownames(rt)=rt[,1]
rt=rt[,-1]
expr=rt

# 加载immunotherapy-predicted pathways
immPath <- read.table("25.immunepathway/immunotherapy predicted pathways.txt",sep = "\t",row.names = 1,check.names = F,stringsAsFactors = F,header = T)
immPath.list <- list()
for (i in rownames(immPath)){
  tmp <- immPath[i,"Genes"]
  tmp <- toupper(unlist(strsplit(tmp,",",fixed = T)))
  tmp <- gsub(" ","",tmp)
  immPath.list[[i]] <- tmp
}

immPath.score <- gsva(expr = as.matrix(expr),
                      immPath.list, 
                      method = "ssgsea",
                      min.sz=1)

# 保存到文件，便于套用
write.table(immPath.score, "25.immunepathway/immuno.gsva.txt",sep = "\t",row.names = T,col.names = NA,quote = F)








