expr <- read.table("1.Datasets/normalize/Emtab.normalize.txt",
                   sep = "\t",row.names = 1,check.names = F,stringsAsFactors = F,header = T)


rt1=read.table("8.uniox/uniCox.e.txt",sep = "\t",header = T)
indata <- t(scale(t(expr)))
expr.A <- indata[rt1$id,]
pca.A <- prcomp(t(expr.A), scale = F, center = F) # 如果数据没有标准化，这里都要设置为TRUE
pca1.A <- pca.A$x[,1] # 取出第一主成分
pca1.B <- pca.A$x[,2] # 取出第二主成分

LRT.score <- pca1.A+pca1.B  # 主成份相减得到ICI得分
LRT.outtab <- data.frame(samID = colnames(indata),
                         pca1.A = pca1.A[colnames(indata)],
                         pca1.B = pca1.B[colnames(indata)],
                         LRT.score = LRT.score[colnames(indata)],
                         stringsAsFactors = F)
# 输出到文件
write.table(LRT.outtab,"9.computePCA/output_LRT_scorePlus.E.txt",sep = "\t",row.names = F,col.names = T,quote = F)


