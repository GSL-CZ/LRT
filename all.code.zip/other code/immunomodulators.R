
rt1=import("17.Immunomodulators/Immunimodulators.txt")
rt2=import('1.Datasets/normalize/tcga.normalize.txt')
rownames(rt2)=rt2[,1]
rt2=rt2[,-1]
rt2=rt2[,-c(1:19)]
colnames(rt2)=substr(colnames(rt2),1,12)
write.table(rt2,file = "1.Datasets/normalize/normlize.tcga.tpm.log2.tumor.txt",
            sep = "\t",quote = F,row.names = T,col.names = NA)

rt=import('1.Datasets/normalize/tcga.sam.txt')
rt2=rt2[,rt$ID]

rt2=rt2[rt1$Genes,]
rt2=as.data.frame(t(rt2))
rt2$ID=rownames(rt2)


rt3=import('4.consensusCluster/Cluster/cluster=2.txt')
rt4=merge(rt3,rt2,by="ID")
rownames(rt4)=rt4[,1]
rt4=rt4[,-1]
rt4=rt4[order(rt4$cluster),]
rt4=rt4[,-92]
###画箱线图
data=melt(rt4,id.vars = "cluster")
colnames(data)=c("cluster","Gene","Expression")

p=ggboxplot(data, x="Gene", y="Expression", fill = "cluster", 
            color = "cluster",
            ylab="Expression",
            xlab="Immunomodulators",
            legend.title="cluster",
            palette = c("#CC3333", "#003366"),
            width = 0.5,horizontal=F)
p=p+rotate_x_text(90)
p1=p+stat_compare_means(aes(group=cluster),
                        method="wilcox.test",
                        symnum.args=list(cutpoints = c(0, 0.001, 0.01, 0.05, 1), symbols = c("***", "**", "*", " ")),
                        label = "p.signif")
p1

###画个热图
rt4=rt4[,-1]
annotation_col <- data.frame(
  LRT_cluster = c(rep("clusterA",times=215),rep("clusterB",times=193))
)
rownames(annotation_col) <- colnames(t(rt4))

annotation_row <- data.frame(
  Type=c(rep("Immunostimulator",times=42),rep("MHC",times=20),
         rep("Receptor",times=18),rep("Chemokine",times=40))
)
rownames(annotation_row) <- rownames(t(rt4))

ann_colors <- list(LRT_cluster=c(clusterA="#FF9933",clusterB="#009966"),
                   Type=c(Immunostimulator="#336633",MHC="#CCCC00",
                          Receptor="#333399",Chemokine="#FF6600"))

pdf("17.Immunomodulators/immunomodulators.cluster.pdf",he=14,wi=6)
pheatmap(t(rt4),
         scale = "row",
         cluster_=T,
         show_colnames = F,
         cluster_rows = F,
         cluster_cols = F,
         gaps_row = c(42,62,80),
         gaps_col =215,
         annotation_col = annotation_col,
         annotation_row = annotation_row,
         color = colorRampPalette(c("#0066CC","BLACK", "#FFFF00"))(200),
         breaks = seq(-2,2,length.out=200),
         annotation_colors = ann_colors)
dev.off()



