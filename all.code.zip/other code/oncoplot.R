library(maftools)
BLCA.maf = read.maf('28.mutation/BLCAvar.maf')
laml.maf=BLCA.maf

#if (as.numeric(dev.cur()) != 1) graphics.off()
plotmafSummary(maf = laml.maf, rmOutlier = TRUE,
               showBarcodes = FALSE,
               addStat = 'median', dashboard = TRUE, titvRaw = FALSE)

oncoplot(laml.maf, 
         draw_titv = F,
         genes = c("ATM","RB1","ERBB2","ERCC2","FANCC"))

lollipopPlot(maf=BLCA.maf, gene="ACOX2", AACol="HGVSp_Short", showMutationRate=TRUE)

rainfallPlot(maf=BLCA.maf, detectChangePoints=TRUE, pointSize=0.6)

plotVaf(maf=BLCA.maf)

BLCA.sig <- oncodrive(maf=BLCA.maf, minMut=5, AACol="HGVSp_Short", pvalMethod="zscore")
plotOncodrive(res = BLCA.sig, fdrCutOff = 0.1, useFraction = TRUE)

Cli=BLCA.maf@clinical.data
colnames(Cli)="Tumor_Sample_Barcode"
Cli$ID=substr(Cli$Tumor_Sample_Barcode,1,12)

score=import("9.computePCA/output_LRT_scorePlus.txt")
score=score[,c(1,4)]
colnames(score)=c("ID","riskscore")
cli=merge(Cli,score,by="ID")
cli$riskscore=ifelse(cli$riskscore>-1.3,"High","Low")


cli.High <- subset(cli, riskscore=="High")$Tumor_Sample_Barcode
cli.Low <- subset(cli,riskscore=="Low")$Tumor_Sample_Barcode

BLCA.High<- subsetMaf(maf=BLCA.maf, tsb=cli.High)
BLCA.Low<- subsetMaf(maf=BLCA.maf, tsb=cli.Low)

vc_cols = RColorBrewer::brewer.pal(n = 8, name = 'Paired')
names(vc_cols) = c(
  'Frame_Shift_Del',
  'Missense_Mutation',
  'Nonsense_Mutation',
  'Multi_Hit',
  'Frame_Shift_Ins',
  'In_Frame_Ins',
  'Splice_Site',
  'In_Frame_Del'
)

pdf("28.mutation/oncoplot.tcga.highscore.pdf",he=5,wi=6)
oncoplot(BLCA.High,genes = c("ATM","RB1","ERBB2","ERCC2","FANCC"),
         fontSize = 1, #size of gene names
         titleFontSize=1.5, #size of title
         #legendFontSize = 2,  #size of legend
         removeNonMutated=T,
         colors = vc_cols,
         titleText = "Altered in 71(34.63%) of 205 High score samples"
         )
dev.off()

pdf("28.mutation/oncoplot.tcga.Lowscore.pdf",he=5,wi=6)
oncoplot(BLCA.Low,genes = c("ATM","RB1","ERBB2","ERCC2","FANCC"),
         fontSize = 1, #size of gene names
         titleFontSize=1.5, #size of title
         colors = vc_cols,
         titleText = "Altered in 92(45.54%) of 202 Low score samples")
dev.off()



pdf("28.mutation/oncoplot.all.highscore.pdf",he=8,wi=7)
oncoplot(BLCA.High,
         fontSize = 1, #size of gene names
         titleFontSize=1.5, #size of title
         #legendFontSize = 2,  #size of legend
         removeNonMutated=T,
         colors = vc_cols,
         titleText = "Altered in 195 (95.12%) of 205 High score samples."
         
)
dev.off()

pdf("28.mutation/oncoplot.all.Lowscore.pdf",he=8,wi=7)
oncoplot(BLCA.Low,
         fontSize = 1, #size of gene names
         titleFontSize=1.5, #size of title
         colors = vc_cols,
         titleText = "Altered in 185 (91.58%) of 202 Low score samples."
         )
dev.off()














